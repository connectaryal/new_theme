	
		<footer>
			<p>This is my footer</p>
			<?php wp_nav_menu(array('theme_location'=>'secondary')); ?>
		</footer>
	
	</div><!-- .container -->
	
	<?php wp_footer(); ?>
	
	</body>
</html>