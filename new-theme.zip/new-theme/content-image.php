<h3>IMAGE POST: <?php the_title(); ?></h3>
<div class="thumbnail-img"><?php the_post_thumbnail('large'); ?></div>

<hr>